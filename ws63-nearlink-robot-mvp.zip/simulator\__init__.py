"""Hardware-free robot simulator."""

